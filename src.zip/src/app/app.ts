import { Component, OnInit, HostListener, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent implements OnInit, AfterViewInit {
  isMenuOpen = false;

  // Variabili per l'effetto scrittura
  private words = ["DASA Studio.", "DASA Web & App.", "DASA Performance."];
  private i = 0;
  private j = 0;
  private isDeleting = false;
  
  // Questa variabile comanda il testo nell'HTML
  public dynamicText = "DASA Studio."; 

  ngOnInit() {
    this.checkScroll();
  }

  ngAfterViewInit() {
    this.j = this.words[0].length; 
    setTimeout(() => this.typeEffect(), 1500);
  }

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    this.checkScroll();
  }

  checkScroll() {
    const reveals = document.querySelectorAll('.reveal');
    reveals.forEach((el) => {
      const windowHeight = window.innerHeight;
      const revealTop = el.getBoundingClientRect().top;
      if (revealTop < windowHeight - 150) {
        el.classList.add('active');
      }
    });
  }

  typeEffect() {
    const currentWord = this.words[this.i];
    
    if (this.isDeleting) {
      this.dynamicText = currentWord.substring(0, this.j - 1);
      this.j--;
    } else {
      this.dynamicText = currentWord.substring(0, this.j + 1);
      this.j++;
    }

    if (!this.isDeleting && this.j === currentWord.length) {
      this.isDeleting = true;
      setTimeout(() => this.typeEffect(), 2500);
    } else if (this.isDeleting && this.j === 0) {
      this.isDeleting = false;
      this.i = (this.i + 1) % this.words.length;
      setTimeout(() => this.typeEffect(), 500);
    } else {
      setTimeout(() => this.typeEffect(), this.isDeleting ? 40 : 100);
    }
  }
}